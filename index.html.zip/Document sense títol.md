﻿#!/usr/bin/env python3

"""

REZZOW — Generador de Arquitectura de Producto

Ejecuta: python3 generate\_rezzow.py

Genera:  index.html  (listo para GitHub Pages)

"""


\# ──────────────────────────────────────────────

\#  DATOS DE LA ARQUITECTURA

\# ──────────────────────────────────────────────


DB\_TABLES = [

{

"id": "tbl-user",

"icon": "👤",

"name": "USER",

"badge": "core",

"badge\_label": "CORE",

"open": True,

"fields": [

("\_id",                  "unique\_id",      "auto", "ID único generado automáticamente por Bubble",                                                              "pk"),

("email",                "text",           "✓",    "Email de acceso único — usado para autenticación",                                                         "idx"),

("full\_name",            "text",           "✓",    "Nombre completo para personalización y perfil público",                                                    ""),

("avatar\_url",           "image",          "—",    "Foto de perfil vía Filestack. Thumbnail 200×200 px generado automáticamente",                              ""),

("nationality",          "text",           "✓",    "ISO 3166-1 alpha-2 del país de origen. Ej: 'ES', 'MX', 'BR'",                                             ""),

("profile\_type",         "option",         "✓",    "Emprendedor / Nómada Digital / Inversor / Trabajador Remoto / Empresa",                                   ""),

("subscription\_plan",    "text",           "auto", "Valores: 'free' | 'pro' | 'enterprise'. Default: 'free' al registrarse",                                   "idx"),

("subscription\_expires", "date",           "—",    "Fecha de caducidad del plan. Null si plan=free. Verificado vía Scheduled Workflow",                        ""),

("stripe\_customer\_id",   "text",           "—",    "ID de cliente en Stripe (cus\_xxx). Asignado al primer intento de pago",                                   "enc"),

("target\_countries",     "list of Country","—",    "Países guardados como favoritos. Máx 3 en free, ilimitado en Pro",                                        "fk"),

("ai\_credits\_used",      "number",         "auto", "Consultas IA consumidas este mes. Reset el día 1 vía Scheduled WF",                                       ""),

("onboarding\_step",      "number",         "auto", "Paso actual del onboarding (0-5). Permite retomar donde se dejó",                                          ""),

("gdpr\_consent\_date",    "date",           "✓",    "Timestamp del consentimiento RGPD. Obligatorio para usuarios de la UE",                                    "enc"),

("preferred\_language",   "option",         "—",    "es / en / pt / fr — determina idioma de la IA y emails",                                                  ""),

("referral\_code",        "text",           "auto", "Código único de referido generado al registrarse (8 chars alphanum)",                                      "idx"),

("referred\_by",          "User",           "—",    "Usuario que hizo el referido — para el sistema de recompensas",                                            "fk"),

],

},

{

"id": "tbl-country",

"icon": "🌍",

"name": "COUNTRY",

"badge": "core",

"badge\_label": "CORE",

"open": False,

"fields": [

("country\_code",            "text",   "✓",    "ISO 3166-1 alpha-2. Ej: 'PT', 'MX', 'TH'. Identificador natural de la tabla",           "pk"),

("name\_es / name\_en",       "text",   "✓",    "Nombre localizado en español e inglés para i18n futura",                                 ""),

("flag\_svg\_url",            "text",   "✓",    "URL a CDN de banderas SVG (flagcdn.com). Ej: https://flagcdn.com/pt.svg",                ""),

("region",                  "option", "✓",    "Europa / Latam / Asia-Pacífico / Oriente Medio / África / Norteamérica / Caribe",        "idx"),

("ease\_of\_business\_score",  "number", "✓",    "Índice Banco Mundial 'Doing Business' 0-100. Para heatmap de negocios",                  ""),

("tax\_burden\_score",        "number", "✓",    "Compuesto IVA+IS+IRPF. 0=alta carga, 100=carga mínima. Escala invertida",               ""),

("safety\_index",            "number", "✓",    "Índice de seguridad Numbeo 0-100. Actualizado trimestralmente",                          ""),

("cost\_of\_living\_index",    "number", "✓",    "Índice Numbeo. Base 100=Nueva York. Para heatmap de coste de vida",                      ""),

("nomad\_score",             "number", "✓",    "Score compuesto (internet+coworking+comunidad expat+visa). 0-100",                       ""),

("internet\_speed\_mbps",     "number", "—",    "Velocidad media Mbps según Ookla Speedtest Global Index",                                ""),

("official\_language",       "list of text","✓","Idiomas oficiales. Array porque hay países con múltiples (Suiza, Bélgica)",              ""),

("currency\_code",           "text",   "✓",    "ISO 4217. Para conversión de precios en el módulo de relocation",                        ""),

("timezone",                "text",   "—",    "Zona horaria IANA principal. Ej: 'Europe/Lisbon'. Para mostrar hora local",              ""),

("capital\_city",            "text",   "✓",    "Ciudad capital, referencia por defecto en datos de relocation",                          ""),

("geojson\_centroid\_lat/lng","number", "✓",    "Coordenadas del centroide para posicionar marcadores en Mapbox",                         ""),

("last\_data\_refresh",       "date",   "auto", "Timestamp de la última actualización vía Scheduled Workflow",                            "auto"),

("is\_featured",             "yes/no", "—",    "Flag editorial para destacar países en homepage y campañas",                             ""),

],

},

{

"id": "tbl-biz",

"icon": "📊",

"name": "BUSINESS\_LAYER",

"badge": "biz",

"badge\_label": "NEGOCIOS B2B",

"open": False,

"fields": [

("country",                  "Country",      "✓", "Relación 1:1 con Country. Un registro por país",                                                    "fk"),

("hs\_codes\_top\_export",      "list of text", "—", "Top 10 códigos HS de exportación. Fuente: ITC Trade Map API",                                       ""),

("hs\_codes\_top\_import",      "list of text", "—", "Top 10 códigos HS de importación. Para emprendedores que importan al país",                         ""),

("avg\_import\_tariff\_pct",    "number",       "—", "Arancel medio ponderado de importación (%). Fuente: WTO Tariff Download Facility",                  ""),

("free\_trade\_zones\_json",    "text (JSON)",  "—", "Array: [{name, city, benefits, url\_oficial}]. Ej: Zona Franca Barranquilla",                        ""),

("trade\_agreements",         "list of text", "—", "TLCs vigentes. Ej: ['UE','MERCOSUR','CPTPP']",                                                       ""),

("trade\_fairs\_json",         "text (JSON)",  "—", "Array: [{name, city, date\_start, date\_end, sector, url, edition}]",                                 ""),

("gdp\_usd\_billions",         "number",       "—", "PIB en miles de millones USD. Fuente FMI. Actualización anual",                                     ""),

("gdp\_growth\_rate",          "number",       "—", "Tasa de crecimiento PIB % último año. Para semáforo de oportunidad",                                ""),

("top\_sectors",              "list of text", "—", "Sectores con mayor actividad e IED (Inversión Extranjera Directa)",                                  ""),

("fdi\_inflow\_usd\_m",         "number",       "—", "Inversión extranjera directa entrante en M USD. Indicador de confianza",                            ""),

("startup\_ecosystem\_score",  "number",       "—", "Score 0-100 del ecosistema startup (Startup Genome Report)",                                         ""),

],

},

{

"id": "tbl-legal",

"icon": "⚖️",

"name": "LEGAL\_LAYER",

"badge": "legal",

"badge\_label": "BUROCRÁTICO",

"open": False,

"fields": [

("country",                       "Country",     "✓", "Relación 1:1 con Country",                                                                           "fk"),

("company\_formation\_steps\_json",  "text (JSON)", "—", "Array: [{step\_num, action\_es, time\_days, cost\_usd, document\_needed, authority}]",                     ""),

("company\_types",                 "list of text","—", "Formas jurídicas disponibles con nombre local y equivalente español",                                 ""),

("min\_capital\_usd",               "number",      "—", "Capital mínimo requerido para constituir empresa (USD)",                                              ""),

("corporate\_tax\_rate",            "number",      "—", "Tipo general del Impuesto de Sociedades (%)",                                                         ""),

("vat\_rate",                      "number",      "—", "Tipo estándar IVA o equivalente (GST, VAT, IGV...) (%)",                                              ""),

("income\_tax\_brackets\_json",      "text (JSON)", "—", "Array: [{from\_usd, to\_usd, rate\_pct, label}]. Para gráfico de tramos IRPF",                          ""),

("territorial\_tax\_system",        "yes/no",      "—", "TRUE si solo tributan rentas de fuente local (Panamá, Paraguay...)",                                  ""),

("tax\_treaty\_with\_spain",         "yes/no",      "—", "¿Convenio de doble imposición con España?",                                                          ""),

("social\_security\_rate\_employer", "number",      "—", "Cotización Seguridad Social empleador (%). Para comparar coste de contratación",                     ""),

("special\_tax\_regimes\_json",      "text (JSON)", "—", "Regímenes especiales: [{name, description, conditions, benefit, url\_oficial}]",                      ""),

],

},

{

"id": "tbl-visa",

"icon": "🛂",

"name": "VISA\_GUIDE",

"badge": "legal",

"badge\_label": "BUROCRÁTICO",

"open": False,

"fields": [

("country",                    "Country",     "✓", "País al que aplica. Un país puede tener múltiples VisaGuide",                                        "fk"),

("visa\_type",                  "option",      "✓", "Nómada Digital / Inversor / Trabajo / Residencia Temporal / Residencia Permanente / Ciudadanía",     "idx"),

("visa\_name\_local",            "text",        "—", "Nombre oficial local. Ej: 'D8 Visa' (Portugal). Para credibilidad",                                  ""),

("steps\_json",                 "text (JSON)", "✓", "Array: [{step\_num, title, description, time\_days\_min, time\_days\_max, cost\_usd, documents, tips, url}]",""),

("min\_income\_usd\_month",       "number",      "—", "Ingresos mínimos mensuales requeridos en USD para aplicar",                                          ""),

("min\_investment\_usd",         "number",      "—", "Inversión mínima requerida (visas de inversor). Null en visas de trabajo",                           ""),

("total\_cost\_estimate\_usd",    "number",      "—", "Coste total estimado (tasas + apostillas + gestores + viajes)",                                       ""),

("processing\_time\_days",       "number",      "—", "Tiempo medio de tramitación en días hábiles desde entrega completa",                                  ""),

("valid\_for\_months",           "number",      "—", "Validez inicial de la visa en meses",                                                                 ""),

("physical\_presence\_required", "yes/no",      "—", "¿Requiere presencia física para tramitar? Crucial para nómadas",                                     ""),

("last\_verified\_date",         "date",        "✓", "Fecha verificación manual por equipo REZZOW. Alerta si > 90 días sin verificar",                    "enc"),

("difficulty\_level",           "option",      "—", "Fácil / Media / Difícil / Muy difícil — valoración editorial del equipo",                           ""),

],

},

{

"id": "tbl-reloc",

"icon": "🏠",

"name": "RELOCATION\_LAYER",

"badge": "life",

"badge\_label": "VIDA",

"open": False,

"fields": [

("country",                  "Country",     "✓",    "País al que pertenece esta ciudad",                                                                     "fk"),

("city\_name",               "text",        "✓",    "Nombre de la ciudad. Un país puede tener múltiples ciudades",                                           "idx"),

("is\_capital",              "yes/no",      "auto", "Indica si es la capital (dato por defecto en la ficha país)",                                           ""),

("avg\_rent\_studio\_usd",     "number",      "—",    "Alquiler medio estudio/1 hab centro (USD/mes). Fuente: scraping Numbeo",                               ""),

("avg\_rent\_1br\_center\_usd", "number",      "—",    "Alquiler medio 1 dormitorio zona centro (USD/mes)",                                                     ""),

("avg\_rent\_1br\_outside\_usd","number",      "—",    "Alquiler medio 1 dormitorio periferia (USD/mes). Suele ser 30-40% más barato",                         ""),

("avg\_rent\_3br\_center\_usd", "number",      "—",    "Alquiler medio 3 dormitorios centro (USD/mes). Para familias",                                          ""),

("utilities\_monthly\_usd",   "number",      "—",    "Media servicios básicos/mes: luz, agua, calefacción, basura (USD)",                                     ""),

("coworking\_avg\_day\_usd",   "number",      "—",    "Precio medio día coworking (USD). Para nómadas digitales",                                              ""),

("healthcare\_score",        "number",      "—",    "Calidad sistema sanitario 0-100 (Numbeo Health Care Index)",                                            ""),

("safety\_city\_score",       "number",      "—",    "Índice de seguridad específico de la ciudad",                                                           ""),

("expat\_community\_score",   "number",      "—",    "Tamaño y actividad de la comunidad expat 0-100",                                                        ""),

("monthly\_budget\_single\_usd","number",     "auto", "Presupuesto mensual estimado para vivir cómodo (soltero). Campo calculado",                             "auto"),

("scraping\_source\_urls",    "list of text","—",    "URLs usadas para scraping. Múltiples fuentes para triangular datos",                                    "enc"),

("data\_updated\_at",         "date",        "auto", "Timestamp del último scraping exitoso. Si > 15 días: mostrar badge de aviso",                          "auto"),

],

},

{

"id": "tbl-expert",

"icon": "🤝",

"name": "EXPERT (Partner)",

"badge": "social",

"badge\_label": "MARKETPLACE",

"open": False,

"fields": [

("user\_account",         "User",          "✓",    "Cuenta de usuario vinculada. El experto tiene doble perfil",                                          "fk"),

("specialty",            "option",        "✓",    "Abogado / Asesor Fiscal / Gestor / RRHH / Agente Inmobiliario / Consultor / Traductor",               "idx"),

("bio\_es / bio\_en",      "text",          "✓",    "Descripción profesional bilingüe. Máx 500 caracteres",                                                ""),

("countries\_covered",    "list of Country","✓",   "Países en los que presta servicios. Determina en qué fichas aparece",                                 "fk"),

("languages",            "list of text",  "✓",    "Idiomas con fluidez. Formato ISO 639-1 ['es','en','pt']",                                             ""),

("hourly\_rate\_usd",      "number",        "✓",    "Tarifa por hora en USD. Puede ser 0 (primera consulta gratis)",                                       ""),

("avg\_rating",           "number",        "auto", "Media de todas las valoraciones. Campo calculado, actualizado tras cada Review",                      "auto"),

("total\_reviews",        "number",        "auto", "Contador de reviews recibidas",                                                                        ""),

("is\_verified",          "yes/no",        "auto", "Verificación manual por equipo REZZOW. Default false",                                                ""),

("verification\_docs",    "list of file",  "—",    "Documentos subidos para verificación. Solo visibles por admin",                                       "enc"),

("calendly\_url",         "text",          "—",    "URL de su Calendly. Se embebe en su perfil para agendar directamente",                                ""),

("stripe\_connect\_id",    "text",          "—",    "ID de cuenta Stripe Connect para recibir pagos menos comisión REZZOW",                                "enc"),

("featured\_in\_countries","list of Country","—",   "Países donde aparece como 'Partner Destacado'",                                                       "fk"),

("response\_time\_hours",  "number",        "auto", "Tiempo medio de respuesta en horas (últimos 10 mensajes)",                                            "auto"),

],

},

{

"id": "tbl-review",

"icon": "⭐",

"name": "REVIEW",

"badge": "social",

"badge\_label": "SOCIAL",

"open": False,

"fields": [

("expert",          "Expert",  "✓",    "Experto valorado",                                                                              "fk"),

("reviewer",        "User",    "✓",    "Usuario que escribe la review. Privacy: solo visible por reviewer o admin",                     "fk"),

("rating",          "number",  "✓",    "Valoración 1-5. Integer. Validado con constraint en Bubble",                                    ""),

("comment",         "text",    "—",    "Comentario textual. Máx 500 chars. Moderado antes de publicar (is\_approved)",                  ""),

("is\_approved",     "yes/no",  "auto", "Moderación automática vía OpenAI Moderation API. Default false",                               ""),

("service\_country", "Country", "—",    "País para el que se contrató el servicio. Para filtrar reviews por contexto",                  "fk"),

("created\_at",      "date",    "auto", "Timestamp de creación",                                                                         "auto"),

("helpful\_votes",   "number",  "auto", "Votos 'fue útil'. Para ordenar reviews por relevancia",                                        ""),

],

},

{

"id": "tbl-ai",

"icon": "🤖",

"name": "AI\_CONVERSATION",

"badge": "core",

"badge\_label": "IA",

"open": False,

"fields": [

("user",            "User",        "✓",    "Propietario. Privacy rule absoluta: solo accesible por el propio usuario",                    "fk"),

("title",           "text",        "auto", "Auto-generado: primeros 40 chars del primer mensaje del usuario",                            ""),

("context\_country", "Country",     "—",    "País activo cuando se inició la sesión. Incluido en system prompt",                          "fk"),

("context\_page",    "text",        "—",    "Pantalla activa al iniciar chat. Ej: 'visa\_guide', 'dashboard'",                             ""),

("context\_tab",     "text",        "—",    "Tab activa en country profile — para hiperpersonalizar la IA",                               ""),

("messages\_json",   "text (JSON)", "✓",    "Array: [{role, content, timestamp, tokens}]. Privacy: ENCRYPTED",                           "enc"),

("model\_used",      "text",        "auto", "Modelo OpenAI utilizado. Registrado para análisis de costes y calidad",                     ""),

("total\_tokens",    "number",      "auto", "Total tokens consumidos (input + output). Para control de costes",                           ""),

("rating\_user",     "number",      "—",    "Rating 1-5 dado por el usuario al finalizar. Para métricas de calidad",                    ""),

("created\_at",      "date",        "auto", "Timestamp de creación y última modificación",                                                "auto"),

],

},

{

"id": "tbl-msg",

"icon": "💬",

"name": "DIRECT\_MESSAGE",

"badge": "social",

"badge\_label": "COMUNIDAD",

"open": False,

"fields": [

("sender",         "User",  "✓",    "Usuario remitente. Privacy: solo visible por sender y receiver",                                 "fk"),

("receiver",       "User",  "✓",    "Usuario destinatario",                                                                            "fk"),

("content",        "text",  "✓",    "Contenido del mensaje. Máx 2000 chars. Sanitizar en backend",                                    "enc"),

("thread\_id",      "text",  "auto", "ID de hilo (hash de sender+receiver IDs ordenados). Para agrupar conversaciones",               "idx"),

("read\_at",        "date",  "—",    "Timestamp de lectura. Null = no leído. Para badge de mensajes sin leer",                        ""),

("is\_flagged",     "yes/no","auto", "Flag de contenido reportado. Para moderación. Default false",                                    ""),

("created\_at",     "date",  "auto", "Timestamp de creación",                                                                          "auto"),

("attachment\_url", "file",  "—",    "Adjunto opcional (PDF, imagen). Máx 5MB",                                                       ""),

],

},

{

"id": "tbl-job",

"icon": "💼",

"name": "JOB\_POSTING",

"badge": "social",

"badge\_label": "JOB BOARD",

"open": False,

"fields": [

("company\_user",        "User",    "✓",    "Empresa que publica. Debe tener profile\_type=Empresa",                                            "fk"),

("title",               "text",    "✓",    "Título del puesto. Ej: 'Senior Backend Dev (Relocation to Portugal)'",                           ""),

("description",         "text",    "✓",    "Descripción completa. Acepta Markdown. Máx 5000 chars",                                          ""),

("location\_country",    "Country", "✓",    "País donde se realiza el trabajo o donde se requiere residir",                                    "fk"),

("work\_type",           "option",  "✓",    "Remoto / Presencial / Híbrido / Freelance",                                                      ""),

("sector",              "option",  "✓",    "Tech / Construcción / Finanzas / Legal / Salud / Marketing / Hostelería / Educación",             "idx"),

("visa\_sponsorship",    "yes/no",  "✓",    "🔑 Diferenciador clave: la empresa tramita la visa. Filtro principal del Job Board",              "idx"),

("salary\_min/max",      "number",  "—",    "Rango salarial anual USD. Opcional pero aumenta conversión un 40%",                              ""),

("required\_languages",  "list of text","—","Idiomas requeridos para filtrar candidatos relevantes",                                           ""),

("expires\_at",          "date",    "✓",    "Fecha de expiración. Scheduled WF la desactiva automáticamente",                                  ""),

("is\_active",           "yes/no",  "auto", "Flag de visibilidad. Auto-desactivado si expires\_at < now",                                      "idx"),

("applications\_count",  "number",  "auto", "Contador de candidaturas recibidas",                                                              ""),

],

},

{

"id": "tbl-notif",

"icon": "🔔",

"name": "NOTIFICATION",

"badge": "system",

"badge\_label": "SISTEMA",

"open": False,

"fields": [

("user",       "User",   "✓",    "Destinatario de la notificación",                                                                                "fk"),

("type",       "option", "✓",    "price\_update / legal\_change / new\_message / expert\_reply / job\_match / system",                            ""),

("title",      "text",   "✓",    "Título corto. Máx 80 chars",                                                                                ""),

("body",       "text",   "✓",    "Cuerpo. Puede incluir variables interpoladas",                                                             ""),

("link\_url",   "text",   "—",    "URL interna de destino al hacer click. Ej: '/country/PT?tab=legal'",                                       ""),

("is\_read",    "yes/no", "auto", "Flag de lectura. Default false. Se marca al hacer click",                                                  ""),

("created\_at", "date",   "auto", "Timestamp. Se eliminan automáticamente las notificaciones > 90 días",                                      "auto"),

],

},

{

"id": "tbl-ref",

"icon": "🎁",

"name": "REFERRAL",

"badge": "system",

"badge\_label": "SISTEMA",

"open": False,

"fields": [

("referrer",           "User",   "✓",    "Usuario que hizo el referido",                                                                             "fk"),

("referred\_user",      "User",   "✓",    "Nuevo usuario que se registró con el código",                                                           "fk"),

("status",             "option", "auto", "pending / converted / rewarded. Se actualiza cuando referred\_user se hace PRO",                        ""),

("reward\_type",        "text",   "—",    "Tipo de recompensa: '1\_month\_free' / '20\_eur\_credit' / 'ai\_credits\_50'",                            ""),

("reward\_applied\_at",  "date",   "—",    "Timestamp de aplicación de la recompensa al referrer",                                               ""),

("created\_at",         "date",   "auto", "Fecha de registro del referred\_user con el código",                                                   "auto"),

],

},

]




WORKFLOWS = [

{

"id": "wf1",

"icon": "🧠",

"title": "WF-01 — IA Contextual con Datos en Vivo",

"tags": [("tag-critical", "Crítico"), ("tag-ai", "IA")],

"open": True,

"desc": (

"El workflow más importante de REZZOW. El chat de IA no es genérico — "

"construye un system prompt dinámico con los datos reales del país activo "

"en cada sesión. Esto elimina alucinaciones y hace que la IA responda como "

"un experto real en ese destino específico."

),

"steps": [

{

"name": "Trigger: click en 'Enviar' en AI\_Chat\_Input",

"detail": (

"Evento: 'When AI\_Send\_Button is clicked'. Captura: message\_text = AI\_Input's value, "

"current\_country = Page's country\_code, current\_page = Current Page Name, "

"current\_tab = Group\_Tabs's current\_tab\_state."

),

"code": None,

},

{

"name": "Verificar Gate Freemium",

"detail": "Condición: Only when Current User's ai\_credits\_used < límite del plan. Si falla: Show Popup 'upgrade\_to\_pro'.",

"code": (

"// Bubble Condition\n"

"IF Current User's subscription\_plan = \"free\"\n"

"  AND Current User's ai\_credits\_used >= 10\n"

"  THEN Show Popup upgrade\_modal  // STOP\n"

"ELSE IF subscription\_plan = \"pro\"\n"

"  AND ai\_credits\_used >= 200\n"

"  THEN Show \"Límite mensual alcanzado\"  // STOP\n"

"ELSE  // Continue workflow"

),

},

{

"name": "Construir System Prompt Dinámico",

"detail": (

"Usar 'Set State' para combinar datos de la DB del país activo. "

"Este paso es la 'magia': la IA sabe exactamente en qué contexto está."

),

"code": (

"Eres REZZOW AI, experto en movilidad global.\n"

"Responde SIEMPRE en [Current User's preferred\_language].\n\n"

"## CONTEXTO\n"

"- País: [Country's name\_es] ([country\_code])\n"

"- Perfil: [Current User's profile\_type]\n"

"- Pantalla: [Current Page Name]\n\n"

"## DATOS FISCALES\n"

"- IS: [corporate\_tax\_rate]%\n"

"- IVA: [vat\_rate]%\n"

"- Sistema territorial: [territorial\_tax\_system]\n\n"

"## DATOS DE VIDA\n"

"- Alquiler 1 hab. centro: [avg\_rent\_1br\_center\_usd] USD\n"

"- Servicios/mes: [utilities\_monthly\_usd] USD\n"

"- Seguridad: [safety\_index]/100\n\n"

"REGLAS: Sé conciso (máx 200 palabras). Da 3 acciones concretas.\n"

"NUNCA inventes datos. Si no sabes: di la fuente oficial."

),

},

{

"name": "Llamada API OpenAI desde Backend Workflow",

"detail": "La API Key nunca queda expuesta en el frontend. El historial completo de la conversación se envía en cada llamada.",

"code": (

"POST https://api.openai.com/v1/chat/completions\n"

"Authorization: Bearer [OpenAI\_Key -- BACKEND ONLY]\n\n"

"{\n"

"  \"model\": \"gpt-4o\",\n"

"  \"messages\": [\n"

"    {\"role\":\"system\", \"content\":\"[SYSTEM\_PROMPT]\"},\n"

"    // ...historial de messages\_json...\n"

"    {\"role\":\"user\", \"content\":\"[message\_text]\"}\n"

"  ],\n"

"  \"max\_tokens\": 600,\n"

"  \"temperature\": 0.35\n"

"}"

),

},

{

"name": "Guardar en AIConversation + actualizar créditos",

"detail": (

"Make changes to AIConversation: añadir mensaje usuario + respuesta IA al messages\_json. "

"Incrementar ai\_credits\_used del User en +1. Actualizar total\_tokens."

),

"code": None,

},

{

"name": "Mostrar respuesta con efecto Typewriter",

"detail": "Plugin 'Typewriter Effect' + JavaScript custom para scroll automático al último mensaje.",

"code": (

"// Scroll al último mensaje\n"

"const chat = document.getElementById('rg\_chat');\n"

"chat.scrollTo({ top: chat.scrollHeight, behavior: 'smooth' });"

),

},

],

},

{

"id": "wf2",

"icon": "🔄",

"title": "WF-02 — Scraping Automático de Precios (Apify)",

"tags": [("tag-scheduled", "Scheduled")],

"open": False,

"desc": (

"Cada 72 horas Bubble ejecuta un Backend Workflow que actualiza precios de alquiler "

"y coste de vida para todas las ciudades activas. Usa Apify para evitar bloqueos IP "

"y cumplir con robots.txt."

),

"steps": [

{

"name": "Scheduled Backend WF — cada 72h",

"detail": "Lista de items: Search for RelocationLayer where data\_updated\_at < Current datetime - 72 hours.",

"code": None,

},

{

"name": "POST a Apify Actor (Numbeo Scraper)",

"detail": "Apify gestiona proxies rotativos, headless browser y parseo del HTML.",

"code": (

"POST https://api.apify.com/v2/actor-tasks/[task\_id]/runs\n"

"  ?token=[APIFY\_TOKEN]\n"

"Body: {\n"

"  \"input\": {\n"

"    \"url\": \"https://numbeo.com/cost-of-living/in/[city]\",\n"

"    \"fields\": [\"rent\_1br\_center\",\"rent\_1br\_outside\",\n"

"               \"rent\_3br\_center\",\"utilities\"]\n"

"  }\n"

"}\n"

"// Webhook: https://[app].bubbleapps.io/api/1.1/wf/apify\_webhook"

),

},

{

"name": "Webhook de Apify → parsear + validar datos",

"detail": "Comparar con datos anteriores. Si cambio > 50%: marcar como outlier y no guardar automáticamente.",

"code": None,

},

{

"name": "Actualizar RelocationLayer + Notificar usuarios",

"detail": "data\_updated\_at = now. Buscar Users donde target\_countries contains este Country → crear Notification type=price\_update.",

"code": None,

},

],

},

{

"id": "wf3",

"icon": "💳",

"title": "WF-03 — Gestión Completa de Suscripción Stripe",

"tags": [("tag-payment", "Pagos"), ("tag-critical", "Crítico")],

"open": False,

"desc": "Flujo completo del ciclo de vida: alta, renovación, cancelación y downgrade. Todo vía webhooks de Stripe para garantizar consistencia.",

"steps": [

{

"name": "Usuario click 'Upgrade a Pro'",

"detail": "Crear Stripe Customer si no existe → POST /checkout/sessions con price\_id del plan.",

"code": (

"POST https://api.stripe.com/v1/checkout/sessions\n"

"Body:\n"

"  customer: [User's stripe\_customer\_id]\n"

"  mode: \"subscription\"\n"

"  line\_items[0][price]: \"price\_xxx\_pro\_monthly\"\n"

"  success\_url: \"https://rezzow.com/dashboard?upgraded=true\"\n"

"  metadata[bubble\_user\_id]: [Current User's \_id]"

),

},

{

"name": "Webhook: checkout.session.completed",

"detail": "Verificar firma stripe-signature con webhook secret. Extraer bubble\_user\_id del metadata.",

"code": None,

},

{

"name": "Actualizar User + Email de Bienvenida Pro",

"detail": "subscription\_plan='pro', subscription\_expires=now+30days, ai\_credits\_used=0. Email vía SendGrid.",

"code": None,

},

{

"name": "Webhook: invoice.payment\_failed → Gracia 7 días",

"detail": "No degradar inmediatamente. Enviar email de alerta. Si sigue fallando a los 7 días → Scheduled WF degrada a free.",

"code": None,

},

{

"name": "Webhook: customer.subscription.deleted → Downgrade",

"detail": "subscription\_plan='free', subscription\_expires=null. Crear Notification tipo system informando del cambio.",

"code": None,

},

],

},

{

"id": "wf4",

"icon": "🗺️",

"title": "WF-04 — Heatmap Interactivo Mapbox",

"tags": [("tag-ui", "UI Logic")],

"open": False,

"desc": "El mapa recalcula colores en el cliente con JavaScript, sin llamadas al servidor. Los datos se precargan en un JSON inicial para máxima velocidad.",

"steps": [

{

"name": "Page Load: precargar datos de todos los países",

"detail": "Backend API Workflow devuelve JSON con todos los Country records y sus scores. Se guarda en Custom State.",

"code": None,

},

{

"name": "Inicializar Mapbox con GeoJSON mundial",

"detail": "HTML Element carga Mapbox GL JS con estilo 'navigation-night-v1' y proyección 'globe'.",

"code": (

"mapboxgl.accessToken = 'pk.xxx';\n"

"const map = new mapboxgl.Map({\n"

"  container: 'map',\n"

"  style: 'mapbox://styles/mapbox/navigation-night-v1',\n"

"  projection: 'globe',\n"

"  zoom: 2, center: [10, 20]\n"

"});\n"

"window.addEventListener('message', (e) => {\n"

"  if (e.data.type === 'REZZOW\_DATA') applyHeatmap(e.data);\n"

"});"

),

},

{

"name": "Filtro seleccionado → recalcular colores",

"detail": "Al cambiar Custom State 'active\_filter', el HTML Element recibe el evento y recalcula fill-color de cada feature GeoJSON.",

"code": (

"function scoreToColor(score) {\n"

"  const h = score \* 1.2;  // 0=rojo, 120=verde\n"

"  return `hsl(${h}, 85%, 45%)`;\n"

"}\n"

"map.setPaintProperty('countries-fill', 'fill-color', [\n"

"  'interpolate', ['linear'], ['get', activeFilter],\n"

"  0,   '#ff3d6b',\n"

"  50,  '#ffcc00',\n"

"  100, '#39ff84'\n"

"]);"

),

},

{

"name": "Click en país → navigate to Country Profile",

"detail": "Click en layer de Mapbox → bubbleEvent → Bubble captura con 'When a JavaScript event occurs' → Navigate con parámetro country\_code.",

"code": None,

},

],

},

{

"id": "wf5",

"icon": "📄",

"title": "WF-05 — Generación de Checklist PDF (PDFMonkey)",

"tags": [("tag-pro", "Solo PRO")],

"open": False,

"desc": "Los checklists son uno de los principales imanes de conversión a Pro. Se generan dinámicamente con datos del país y la visa seleccionada.",

"steps": [

{

"name": "Click 'Descargar Checklist' — Gate PRO",

"detail": "Condición: Only when Current User's subscription\_plan is not 'free'. Si es free: modal con propuesta de valor Pro.",

"code": None,

},

{

"name": "POST a PDFMonkey con datos del VisaGuide",

"detail": "Payload incluye pasos, documentos, costes, tiempos y expertos recomendados para ese país y visa.",

"code": (

"POST https://api.pdfmonkey.io/api/v1/documents\n"

"Authorization: Bearer [PDFMONKEY\_KEY]\n"

"Body: {\n"

"  \"document\": {\n"

"    \"document\_template\_id\": \"tmpl\_visa\_checklist\_v2\",\n"

"    \"payload\": {\n"

"      \"country\_name\": \"Portugal\",\n"

"      \"visa\_type\": \"Nómada Digital D8\",\n"

"      \"user\_name\": [User's full\_name],\n"

"      \"steps\": [...],\n"

"      \"estimated\_cost\": 850,\n"

"      \"processing\_days\": 45\n"

"    }\n"

"  }\n"

"}"

),

},

{

"name": "Webhook PDFMonkey → download\_url → descarga",

"detail": "Se recibe la URL del PDF generado. Plugin 'Download File from URL' → descarga con nombre 'REZZOW\_Checklist\_PT\_Nomada.pdf'.",

"code": None,

},

],

},

{

"id": "wf6",

"icon": "🛡️",

"title": "WF-06 — Moderación IA de Contenido",

"tags": [("tag-security", "Seguridad"), ("tag-ai", "IA")],

"open": False,

"desc": "Reviews y mensajes directos pasan por OpenAI Moderation API antes de publicarse. Reduce carga de moderación manual y protege la plataforma.",

"steps": [

{

"name": "Trigger: Review creada o Mensaje enviado",

"detail": "Backend WF se dispara al crear Review o DirectMessage. is\_approved = false por defecto.",

"code": None,

},

{

"name": "Llamada a OpenAI Moderation API (gratuita)",

"detail": "Detecta: hate, harassment, self-harm, sexual, violence. Devuelve scores y flag 'flagged' boolean.",

"code": (

"POST https://api.openai.com/v1/moderations\n"

"Body: { \"input\": \"[content\_to\_check]\" }\n\n"

"// Response:\n"

"{\n"

"  \"results\": [{\n"

"    \"flagged\": false,\n"

"    \"categories\": { \"hate\": false, ... },\n"

"    \"category\_scores\": { \"hate\": 0.002, ... }\n"

"  }]\n"

"}"

),

},

{

"name": "Decisión: aprobar o escalar a admin",

"detail": "Si flagged=false → is\_approved=true. Si flagged=true → is\_flagged=true + Notification para admin + email alerta.",

"code": None,

},

],

},

{

"id": "wf7",

"icon": "🔔",

"title": "WF-07 — Alertas de Cambios Legales (Perplexity)",

"tags": [("tag-scheduled", "Scheduled"), ("tag-ai", "IA")],

"open": False,

"desc": "Diariamente la IA escanea noticias legales con Perplexity API (acceso a internet en tiempo real). Si detecta cambios en visas o fiscalidad, alerta a usuarios afectados.",

"steps": [

{

"name": "Scheduled WF — cada 24h por país prioritario",

"detail": "Lista de países con > 10 usuarios guardándolo. Priorización por popularidad para optimizar costes.",

"code": None,

},

{

"name": "Consulta a Perplexity API (web real-time)",

"detail": "Perplexity tiene acceso a internet, a diferencia de GPT base. Responde en JSON estructurado.",

"code": (

"POST https://api.perplexity.ai/chat/completions\n"

"Body: {\n"

"  \"model\": \"sonar-pro\",\n"

"  \"messages\": [{\n"

"    \"role\": \"user\",\n"

"    \"content\": \"Busca noticias últimas 24h sobre cambios\n"

"    en visas, impuestos o leyes para extranjeros\n"

"    en Portugal. Responde SOLO en JSON:\n"

"    {has\_changes: bool, summary: string,\n"

"    severity: 'low'|'medium'|'high', source\_url}\"\n"

"  }]\n"

"}"

),

},

{

"name": "Si has\_changes=true → notificar usuarios Pro",

"detail": "severity='high' → push OneSignal + email SendGrid a todos los Pro con ese país en target\_countries. severity='low' → solo notificación in-app.",

"code": None,

},

],

},

{

"id": "wf8",

"icon": "🎁",

"title": "WF-08 — Sistema de Referidos",

"tags": [("tag-payment", "Growth")],

"open": False,

"desc": "Flujo completo: generación de código único, tracking de conversión y aplicación automática de recompensas a ambas partes.",

"steps": [

{

"name": "Registro con código de referido (?ref=XXX)",

"detail": "Campo referral\_code oculto pre-rellenado si viene de URL. Al crear User: buscar User donde referral\_code = campo → crear Referral record.",

"code": None,

},

{

"name": "Referido se hace PRO → trigger recompensa",

"detail": "Webhook Stripe detecta nuevo subscriptor. Backend WF busca Referral donde referred\_user=este User y status='pending'.",

"code": None,

},

{

"name": "Aplicar recompensas a ambos usuarios",

"detail": "Referrer: subscription\_expires += 30 days. Referred: 20 créditos IA extra. Actualizar Referral status='rewarded'.",

"code": None,

},

],

},

]




TECH\_STACK = [

("🫧", "Bubble.io",       "Plataforma Core",        "DB, workflows, UI builder, hosting y auth incluidos. Escala a millones de usuarios.",          "$29–529/mes"),

("🗺️", "Mapbox GL JS",    "Cartografía",            "Mapas oscuros vectoriales, GeoJSON, heatmaps y globo 3D. Free tier: 50k cargas/mes.",           "Free / $0.50×1k"),

("🧠", "OpenAI API",      "IA Principal",           "GPT-4o para análisis estratégico. GPT-3.5-turbo para respuestas rápidas. Moderation API gratis.","GPT-4o: $15/1M tok"),

("🌐", "Perplexity AI",   "Búsqueda Real-Time",     "Acceso a internet en tiempo real. Ideal para alertas de cambios legales diarios.",               "Sonar Pro: $3/1M"),

("🕷️", "Apify",           "Web Scraping",           "Actores para Numbeo e Idealista. Proxies rotativos, headless browser, webhooks JSON.",           "$10–49/mes"),

("💳", "Stripe",          "Pagos y Suscripciones",  "Suscripciones, Stripe Connect para pagar a expertos, portal de cliente. Plugin oficial Bubble.", "2.9%+€0.30/tx"),

("📧", "SendGrid",        "Email Transaccional",    "Bienvenida, alertas legales, facturación. Free tier: 100 emails/día.",                           "Free / $19.95/mes"),

("🔔", "OneSignal",       "Push Notifications",     "Notificaciones web y móvil. Segmentación por país de interés. Free hasta 10k subs.",             "Free hasta 10k"),

("📄", "PDFMonkey",       "Generación de PDFs",     "Plantillas HTML/CSS para checklists branded. Variables dinámicas de Bubble.",                    "$19/mes 500 PDFs"),

("📅", "Calendly API",    "Scheduling",             "Embed en perfil de experto. Webhook booking.created → crear Booking en Bubble.",                 "$10/mes por experto"),

("📁", "Filestack",       "File Storage",           "Upload de avatares, CVs, docs de verificación. CDN global, virus scanning.",                     "Free 25tx / $19+"),

("🍪", "Cookiebot",       "Compliance RGPD",        "Banner certificado RGPD/CCPA. Registro de consentimientos para auditoría.",                      "$9/mes 1 dominio"),

("📍", "ipinfo.io",       "Geolocalización IP",     "Detectar país del usuario para pre-seleccionar idioma y leyes RGPD aplicables.",                 "Free 50k req/mes"),

("📊", "Mixpanel",        "Product Analytics",      "Eventos: page view, country viewed, AI query, checkout. Funnels de conversión.",                 "Free 100k eventos"),

("🌐", "Webflow",         "Landing SEO",            "rezzow.com en Webflow para mejor SEO. La app en app.rezzow.com.",                               "$14/mes CMS"),

("🔍", "Algolia",         "Búsqueda Avanzada",      "Fase 2: búsqueda full-text en expertos, jobs y contenido. Plugin Bubble disponible.",            "Free 10k registros"),

]


COMPETITORS = [

\# (feature, rezzow, nomad\_list, internations, numbeo, worldbank, deel)

("Mapa de calor interactivo",         "✓ Avanzado",    "~ Básico",      "✗",           "✗",          "✗",          "✗"),

("Guía de visas paso a paso",         "✓ Completa",    "~ Parcial",     "~ Básica",    "✗",          "✗",          "✓ Solo empleo"),

("Datos fiscales detallados",         "✓ Por tramos",  "✗",             "✗",           "✗",          "~ Limitado", "~ Básico"),

("Precios alquiler tiempo real",      "✓ Scraping",    "✓ Manual",      "✗",           "✓ Crowd.",   "✗",          "✗"),

("IA Asistente contextual",           "✓ GPT-4o",      "✗",             "✗",           "✗",          "✗",          "~ Básico"),

("Marketplace expertos locales",      "✓ Verificado",  "✗",             "✓ Comunidad", "✗",          "✗",          "~ Solo RRHH"),

("Datos B2B (aranceles, HS codes)",   "✓ Completo",    "✗",             "✗",           "✗",          "~ Parcial",  "✗"),

("Creación empresa paso a paso",      "✓ Guiado",      "✗",             "✗",           "✗",          "~ Stats",    "~ Solo Payroll"),

("Job Board para extranjeros",        "✓ +Visa Spons.","✓ Básico",      "~ Red social","✗",          "✗",          "✓ Empleadores"),

("Checklists descargables PDF",       "✓ Generado",    "✗",             "✗",           "✗",          "✗",          "~ Onboarding"),

("Comunidad / Mensajería interna",    "✓ País+Sector", "~ Foro básico", "✓ Avanzado",  "✗",          "✗",          "✗"),

("Modelo Freemium",                   "✓",             "✓",             "✓",           "✓",          "✓ Gratis",   "✗ Solo B2B"),

("Precio Pro",                        "€29/mes",       "$14/mes",       "Gratis",      "Gratis",     "Gratis",     "$599/emp/año"),

]


LEGAL\_CARDS = [

{

"icon": "⚖️",

"title": "RGPD — Base Legal (UE)",

"text": "Cumplimiento completo del RGPD. Bases legales documentadas para cada tipo de procesamiento de datos.",

"items": [

("ok",   "Consentimiento explícito para cookies no esenciales vía Cookiebot"),

("ok",   "Base legal 'ejecución de contrato' para datos de suscripción"),

("ok",   "Registro gdpr\_consent\_date en tabla User para auditoría"),

("",     "DPA firmado con Bubble.io como subprocesador"),

("",     "DPA firmado con OpenAI, Stripe, SendGrid, Apify"),

("warn", "DPO necesario si > 250 empleados o datos sensibles a escala"),

],

},

{

"icon": "🔒",

"title": "Derechos del Usuario",

"text": "Todos los derechos RGPD implementados con workflows en Bubble que los automatizan.",

"items": [

("ok",   "Derecho de acceso: botón 'Exportar mis datos' → CSV completo"),

("ok",   "Derecho de supresión: botón 'Eliminar mi cuenta' → WF borra User + all related"),

("ok",   "Derecho de portabilidad: exportación JSON del historial IA"),

("",     "Derecho de oposición: toggle 'No usar mis datos para mejora de IA'"),

("warn", "Plazo legal máx 30 días. Crear SLA interno para solicitudes"),

("",     "Contacto de privacidad: privacy@rezzow.com"),

],

},

{

"icon": "🛡️",

"title": "Seguridad en Bubble.io",

"text": "Configuración técnica de Privacy Rules y Settings de Bubble.",

"items": [

("ok",   "Privacy Rule User: 'solo cuando This User is Current User'"),

("ok",   "Privacy Rule AIConversation: 'only when user is Current User'"),

("ok",   "Privacy Rule DirectMessage: 'sender is CU OR receiver is CU'"),

("ok",   "TODAS las API Keys en Backend Workflows SOLAMENTE"),

("ok",   "HTTPS forzado. SSL automático con custom domain en Bubble"),

("warn", "Audit log: tabla AuditLog con user, action, timestamp, ip"),

],

},

{

"icon": "⚠️",

"title": "Descargos de Responsabilidad",

"text": "Protección legal frente a la naturaleza consultiva de los datos.",

"items": [

("",     "Banner sticky en Country Profile: 'Datos orientativos. Verificar con profesional'"),

("",     "Cada VisaGuide: 'Última verificación: [fecha]. Las leyes cambian.'"),

("",     "AI Chat: primer mensaje siempre incluye disclaimer legal"),

("warn", "T&C: REZZOW es plataforma informativa, no asesora legal/fiscal"),

("",     "Alerta visual si last\_verified\_date > 90 días sin verificar"),

],

},

{

"icon": "🌍",

"title": "Normativas por Jurisdicción",

"text": "REZZOW opera globalmente. Implementar por capas según país de origen detectado via ipinfo.io.",

"items": [

("ok",   "UE/EEA: RGPD completo + Cookiebot certificado"),

("",     "California (CCPA): enlace 'Do Not Sell My Info' en footer"),

("",     "Brasil (LGPD): consentimiento específico adaptado"),

("warn", "Datos en UE: activar 'EU cluster' en Bubble Settings"),

("",     "Retención: 2 años inactivos, 7 años datos fiscales"),

],

},

{

"icon": "🕷️",

"title": "Web Scraping Legal",

"text": "Marco legal para la actualización automática de precios.",

"items": [

("ok",   "Solo datos públicos sin autenticación requerida"),

("ok",   "Respetar robots.txt de Numbeo, Idealista, Expatistan"),

("ok",   "Apify asume responsabilidad como intermediario"),

("",     "Rate limiting: máx 5 requests/min por dominio"),

("warn", "Evaluar licencia de datos directa con Numbeo (Business API)"),

("",     "No re-publicar contenido original íntegro — solo datos numéricos"),

],

},

{

"icon": "🤝",

"title": "Marco Legal del Marketplace",

"text": "REZZOW actúa como plataforma, no como parte en la relación de servicios.",

"items": [

("",     "Términos específicos para Partners/Expertos (aceptación obligatoria)"),

("",     "Código de conducta: veracidad, tiempos de respuesta, no spam"),

("warn", "Stripe Connect: REZZOW retiene comisión antes de pagar al experto"),

("",     "Sistema de reportes → cola de moderación admin"),

("",     "Política de reembolso: 24h si experto no responde"),

],

},

{

"icon": "🔐",

"title": "Seguridad de la IA",

"text": "Medidas específicas para proteger conversaciones y datos del módulo de IA.",

"items": [

("ok",   "Conversaciones IA cifradas en Bubble DB (campo PRIVATE)"),

("ok",   "No enviar datos PII a OpenAI: user ID anónimo, no email ni nombre"),

("",     "Activar Zero Data Retention en OpenAI si disponible en el plan"),

("warn", "Prompt injection prevention: sanitizar input antes de incluirlo"),

("",     "Límite de tokens de respuesta para prevenir abuso"),

],

},

]


PRICING\_TIERS = [

{

"plan": "// plan base",

"name": "Explorer",

"price": "€0",

"period": "/mes",

"desc": "Para descubrir destinos y evaluar si REZZOW es la herramienta correcta.",

"featured": False,

"features": [

(True,  "Mapa interactivo con 5 heatmaps"),

(True,  "Fichas de país — datos básicos"),

(True,  "10 consultas IA / mes"),

(True,  "Ver 3 expertos por país"),

(True,  "Job Board (solo lectura)"),

(True,  "Comunidad (lectura, no DM)"),

(True,  "3 países guardados"),

(False, "Checklists PDF descargables"),

(False, "IA ilimitada con contexto completo"),

(False, "Comparador de países"),

(False, "Alertas de cambios legales"),

(False, "Mensajería directa"),

],

},

{

"plan": "// plan profesional",

"name": "Global Pro",

"price": "€29",

"period": "/mes",

"desc": "Para profesionales en activo proceso de relocation o expansión.",

"featured": True,

"features": [

(True,  "Todo lo de Explorer"),

(True,  "IA ilimitada (200 consultas/mes) con contexto completo"),

(True,  "Checklists PDF para cualquier visa"),

(True,  "Directorio completo de expertos"),

(True,  "Mensajería directa 1:1"),

(True,  "Comparador hasta 5 países"),

(True,  "Alertas de cambios legales (push + email)"),

(True,  "Datos alquiler en tiempo real"),

(True,  "Historial IA completo"),

(True,  "Job Board: aplicar con CV"),

(True,  "Países guardados ilimitados"),

(False, "Multi-usuario equipo"),

],

},

{

"plan": "// plan empresa",

"name": "Enterprise",

"price": "€149",

"period": "/mes",

"desc": "Para empresas con planes de expansión o equipos gestionando relocations.",

"featured": False,

"features": [

(True,  "Todo lo de Global Pro"),

(True,  "Hasta 10 usuarios en un workspace"),

(True,  "API Access para integrar datos"),

(True,  "Informes de expansión personalizados"),

(True,  "Gestor de cuenta dedicado REZZOW"),

(True,  "SLA: datos actualizados en < 48h"),

(True,  "White-label disponible (+€200/mes)"),

(True,  "Integración con HubSpot/Salesforce"),

(True,  "Facturación corporativa + IVA"),

(True,  "Publicar 2 ofertas de empleo/mes"),

],

},

]


PROJECTIONS = [

\# (metric, m3, m6, m12, m18, m24, m36)

("Usuarios registrados",        "500",     "2.000",    "8.500",    "18.000",    "35.000",    "80.000"),

("Usuarios Pro (5%)",           "25",      "100",      "425",      "900",       "1.750",     "4.000"),

("Usuarios Enterprise (0.3%)",  "1",       "6",        "25",       "54",        "105",       "240"),

("MRR Suscripciones",           "€875",    "€3.794",   "€16.075",  "€34.150",   "€66.475",   "€151.600"),

("Revenue Marketplace (10%)",   "€0",      "€500",     "€3.200",   "€8.500",    "€18.000",   "€45.000"),

("Job Postings (€49/oferta)",   "€0",      "€200",     "€1.500",   "€4.200",    "€9.800",    "€22.000"),

("MRR TOTAL",                   "€875",    "€4.494",   "€20.775",  "€46.850",   "€94.275",   "€218.600"),

("Coste infraestructura",       "€420",    "€650",     "€1.800",   "€3.200",    "€5.500",    "€12.000"),

("MARGEN BRUTO",                "€455",    "€3.844",   "€18.975",  "€43.650",   "€88.775",   "€206.600"),

]


SEO\_CARDS = [

{

"title": "SEO Programático — Fichas País",

"priority": "high",

"priority\_label": "PRIORIDAD ALTA",

"items": [

"Cada Country Profile = landing page: 'Cómo abrir empresa en [País] 2026'",

"Cada VisaGuide = página dedicada: 'Visa nómada digital [País] — requisitos'",

"URLs limpias: /pais/portugal/visa/nomada-digital",

"Meta titles dinámicos desde Bubble con el nombre del país y año",

"Schema markup HowTo para pasos de visa (rich snippets en Google)",

"Potencial: 195 países × 4 tipos visa × 3 idiomas = +2.000 páginas indexables",

],

},

{

"title": "Blog de Contenido (Webflow)",

"priority": "high",

"priority\_label": "PRIORIDAD ALTA",

"items": [

"20 artículos/mes en Webflow (mejor SEO que Bubble). blog.rezzow.com",

"Keywords: 'nómada digital Portugal' (5.400/mes), 'abrir empresa UAE' (2.100/mes)",

"Comparativas: 'Portugal vs Thailand para nómadas 2026' — alta intención",

"Guías definitivas: 'Guía completa visa D8 Portugal 2026' con CTA a la app",

"Casos de éxito: 'Cómo Carlos abrió empresa en Dubai en 47 días'",

"Alerta legal → artículo automático (Perplexity detecta cambio → draft en Notion)",

],

},

{

"title": "Community-Led Growth",

"priority": "med",

"priority\_label": "PRIORIDAD MEDIA",

"items": [

"Canal YouTube: 'Abrimos empresa en [País]' — repurpose del blog",

"TikTok/Reels: '5 cosas que nadie te dice sobre vivir en [País]'",

"Newsletter semanal: 'REZZOW Weekly — novedades movilidad global'",

"Alianzas con creators nómadas digitales (afiliados 30%)",

"Presencia activa en r/digitalnomad, r/expats, Facebook groups de expatriados",

],

},

{

"title": "Product-Led Growth (PLG)",

"priority": "med",

"priority\_label": "PRIORIDAD MEDIA",

"items": [

"Checklist público gratuito (1 país) con watermark REZZOW → viral sharing",

"Widget embebable: 'Coste de vida en Portugal' para blogs de nómadas",

"API pública de datos básicos (rate limited) → backlinks desde desarrolladores",

"Referral program: 1 mes gratis por cada amigo que se hace Pro",

"Comparador público: 'Portugal vs México' embebable y shareable",

],

},

{

"title": "Paid Acquisition (Fase 2)",

"priority": "low",

"priority\_label": "FASE 2",

"items": [

"Google Ads: keywords 'visa nómada digital' (CPC ~$2.50, alta intención)",

"Meta Ads: audiencias lookalike de usuarios Pro existentes",

"Retargeting a visitantes que vieron > 3 fichas de país sin registrarse",

"LinkedIn Ads: target 'Digital Nomad', 'Remote Worker', 'Entrepreneur' en UE/LATAM",

"CAC objetivo: < €15 (actual benchmark SaaS nicho: €12-25)",

],

},

{

"title": "Partnerships B2B",

"priority": "low",

"priority\_label": "FASE 2",

"items": [

"Integraciones con Deel, Remote.com: widget REZZOW en su onboarding",

"Acuerdos con cámaras de comercio: 'Powered by REZZOW' en sus guías",

"Afiliados con agencias de relocation: comisión por leads cualificados",

"Embajadas y consulados: co-marketing para atraer inversión extranjera",

"Asociaciones de nómadas digitales: descuentos corporativos para sus miembros",

],

},

]


COSTS\_DEV = [

("Bubble.io (plan Production, 3 meses)",             "€477"),

("Diseño UX/UI (Figma + Freelancer 2 semanas)",       "€800"),

("Curación datos 5 países piloto (manual)",           "€0"),

("Plantillas PDF (PDFMonkey setup)",                  "€200"),

("Dominio + SSL + email corporativo (1 año)",         "€50"),

("Legal: Términos, Privacidad, T&C Expertos",         "€500"),

("Stripe + Cookiebot configuración",                  "€0"),

]

COSTS\_DEV\_TOTAL = "~€2.027"


COSTS\_OPS = [

("Bubble.io (Production)",                            "€159"),

("OpenAI API (1.000 users × 20 queries avg/mes)",     "€180"),

("Apify (scraping 50 ciudades/semana)",               "€49"),

("Mapbox (hasta 50k cargas/mes)",                     "€0"),

("SendGrid (emails transaccionales)",                 "€20"),

("PDFMonkey (500 PDFs/mes)",                         "€19"),

("OneSignal (push notifications)",                    "€0"),

("Cookiebot + Filestack + misc",                      "€28"),

("Perplexity API (alertas legales diarias)",          "€15"),

]

COSTS\_OPS\_TOTAL = "~€470"




\# ──────────────────────────────────────────────

\#  GENERADORES HTML

\# ──────────────────────────────────────────────


def esc(s: str) -> str:

"""Minimal HTML escaping for content strings."""

return (str(s)

.replace("&", "&amp;")

.replace("<", "&lt;")

.replace(">", "&gt;")

.replace('"', "&quot;"))




def badge\_class(b: str) -> str:

return {"pk": "f-tag pk", "fk": "f-tag fk", "idx": "f-tag idx",

"enc": "f-tag enc", "auto": "f-tag auto", "": "f-tag"}.get(b, "f-tag")




def render\_fields(fields: list) -> str:

rows = []

rows.append(

'<div class="db-fields-header">'

"<span>Campo</span><span>Tipo</span><span>Req.</span>"

"<span>Descripción</span><span>Tag</span></div>"

)

for name, typ, req, desc, tag in fields:

tag\_html = f'<span class="{badge\_class(tag)}">{esc(tag.upper())}</span>' if tag else ""

rows.append(

f'<div class="db-row">'

f'<span class="f-name">{esc(name)}</span>'

f'<span class="f-type">{esc(typ)}</span>'

f'<span class="f-req">{esc(req)}</span>'

f'<span class="f-desc">{esc(desc)}</span>'

f"<span>{tag\_html}</span>"

f"</div>"

)

return "\n".join(rows)




def render\_tables() -> str:

out = ['<div class="tables-grid">']

for t in DB\_TABLES:

open\_cls = " open" if t["open"] else ""

chevron = "▲" if t["open"] else "▼"

fields\_html = render\_fields(t["fields"])

out.append(f"""

<div class="db-table{open\_cls}" id="{t['id']}">

<div class="db-table-head" onclick="toggleTable('{t['id']}')">

<span class="db-table-title">{t['icon']} {esc(t['name'])}</span>

<div class="db-meta">

<span class="db-badge {t['badge']}">{esc(t['badge\_label'])}</span>

<span style="font-size:10px;color:var(--muted)">{len(t['fields'])} campos</span>

<span class="db-chevron">{chevron}</span>

</div>

</div>

<div class="db-body">{fields\_html}</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_code(code: str | None) -> str:

if not code:

return ""

escaped = esc(code)

return f'<div class="code-label">// código de configuración</div><div class="code-block">{escaped}</div>'




def render\_steps(steps: list) -> str:

out = ['<div class="steps-list">']

for i, step in enumerate(steps, 1):

code\_html = render\_code(step.get("code"))

out.append(f"""

<div class="step">

<div class="step-num">{i}</div>

<div class="step-content">

<div class="step-name">{esc(step['name'])}</div>

<div class="step-detail">{esc(step['detail'])}</div>

{code\_html}

</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_workflows() -> str:

out = ['<div class="wf-grid">']

for wf in WORKFLOWS:

open\_cls = " open" if wf["open"] else ""

tags\_html = "".join(

f'<span class="wf-tag {cls}">{esc(lbl)}</span>' for cls, lbl in wf["tags"]

)

steps\_html = render\_steps(wf["steps"])

out.append(f"""

<div class="wf-card{open\_cls}" id="{wf['id']}">

<div class="wf-head" onclick="toggleWF('{wf['id']}')">

<div class="wf-title"><span class="wf-icon">{wf['icon']}</span> {esc(wf['title'])}</div>

<div class="wf-tags">{tags\_html}</div>

</div>

<div class="wf-body">

<div class="wf-desc">{esc(wf['desc'])}</div>

{steps\_html}

</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_tech() -> str:

out = ['<div class="tech-grid">']

for logo, name, role, desc, price in TECH\_STACK:

out.append(f"""

<div class="tech-card">

<div class="tech-logo">{logo}</div>

<div class="tech-name">{esc(name)}</div>

<div class="tech-role">{esc(role)}</div>

<div class="tech-desc">{esc(desc)}</div>

<div class="tech-price">{esc(price)}</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_competitors() -> str:

headers = ["Funcionalidad", "⬡ REZZOW", "Nomad List", "InterNations", "Numbeo", "World Bank", "Deel/Remote"]

rows = ["<table class='comp-table'><thead><tr>"]

for i, h in enumerate(headers):

cls = " class='comp-header-rezzow'" if i == 1 else ""

rows.append(f"<th{cls}>{esc(h)}</th>")

rows.append("</tr></thead><tbody>")

for row in COMPETITORS:

rows.append("<tr>")

for i, cell in enumerate(row):

cls = " class='highlight-col'" if i == 1 else ""

\# colour check/cross/partial

sym = ""

if cell.startswith("✓"):

sym = f'<span class="check">{esc(cell)}</span>'

elif cell.startswith("✗"):

sym = f'<span class="cross">{esc(cell)}</span>'

elif cell.startswith("~"):

sym = f'<span class="partial">{esc(cell)}</span>'

else:

sym = esc(cell)

td\_cls = " class='feat'" if i == 0 else (" class='highlight-col'" if i == 1 else "")

rows.append(f"<td{td\_cls}>{sym}</td>")

rows.append("</tr>")

rows.append("</tbody></table>")

return "\n".join(rows)




def render\_legal() -> str:

out = ['<div class="legal-grid">']

for c in LEGAL\_CARDS:

items\_html = []

for kind, text in c["items"]:

extra = f" {kind}" if kind else ""

items\_html.append(f'<div class="legal-item{extra}">{esc(text)}</div>')

out.append(f"""

<div class="legal-card">

<span class="legal-icon">{c['icon']}</span>

<div class="legal-title">{esc(c['title'])}</div>

<div class="legal-text">{esc(c['text'])}</div>

<div class="legal-items">{''.join(items\_html)}</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_pricing() -> str:

out = ['<div class="pricing-grid">']

for t in PRICING\_TIERS:

featured\_cls = " featured" if t["featured"] else ""

badge = '<div class="featured-badge">MÁS POPULAR</div>' if t["featured"] else ""

feats = []

for active, text in t["features"]:

cls = " active" if active else ""

sym = "f-check" if active else "f-cross"

mark = "✓" if active else "✗"

feats.append(

f'<div class="tier-feature{cls}">'

f'<span class="{sym}">{mark}</span>'

f'<span class="f-text">{esc(text)}</span>'

f"</div>"

)

out.append(f"""

<div class="price-tier{featured\_cls}">

{badge}

<div class="tier-plan">{esc(t['plan'])}</div>

<div class="tier-name">{esc(t['name'])}</div>

<div class="tier-price">{esc(t['price'])}<sub>{esc(t['period'])}</sub></div>

<div class="tier-desc">{esc(t['desc'])}</div>

<div class="tier-features">{''.join(feats)}</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_projections() -> str:

highlight\_rows = {"MRR TOTAL", "MARGEN BRUTO"}

rows = [

"<table class='projection-table'><thead><tr>",

"<th>Métrica</th>",

"<th>Mes 3</th><th>Mes 6</th><th>Mes 12</th>",

"<th>Mes 18</th><th>Mes 24</th><th>Mes 36</th>",

"</tr></thead><tbody>",

]

for metric, \*vals in PROJECTIONS:

if metric in highlight\_rows:

rows.append(f"<tr><td style='color:var(--a1);font-family:\"Bebas Neue\",sans-serif;font-size:15px'>{esc(metric)}</td>")

else:

rows.append(f"<tr><td>{esc(metric)}</td>")

for i, v in enumerate(vals):

cls = "num-accent" if i == len(vals) - 1 else ("num-up" if v.startswith("€") and i > 1 else "num-neutral")

rows.append(f"<td class='{cls}'>{esc(v)}</td>")

rows.append("</tr>")

rows.append("</tbody></table>")

return "\n".join(rows)




def render\_seo() -> str:

out = ['<div class="seo-grid">']

for c in SEO\_CARDS:

items\_html = "".join(f'<div class="seo-item">{esc(i)}</div>' for i in c["items"])

out.append(f"""

<div class="seo-card {c['priority']}">

<div class="seo-title">{esc(c['title'])}</div>

<div class="seo-priority"><span class="priority-dot"></span>{esc(c['priority\_label'])}</div>

<div class="seo-items">{items\_html}</div>

</div>""")

out.append("</div>")

return "\n".join(out)




def render\_costs() -> str:

def cost\_rows(items):

return "".join(

f'<div class="cost-item"><span class="cost-name">{esc(n)}</span>'

f'<span class="cost-val">{esc(v)}</span></div>'

for n, v in items

)


dev = cost\_rows(COSTS\_DEV)

ops = cost\_rows(COSTS\_OPS)

return f"""

<div class="costs-grid">

<div class="cost-phase">

<div class="cost-phase-title">🚀 Coste de Desarrollo (One-Time)</div>

<div class="cost-items">{dev}</div>

<div class="cost-total">

<span class="cost-name">TOTAL MVP LAUNCH</span>

<span class="cost-val">{COSTS\_DEV\_TOTAL}</span>

</div>

</div>

<div class="cost-phase">

<div class="cost-phase-title">📅 Coste Operativo Mensual (Escala)</div>

<div class="cost-items">{ops}</div>

<div class="cost-total">

<span class="cost-name">TOTAL MENSUAL (1.000 users)</span>

<span class="cost-val">{COSTS\_OPS\_TOTAL}</span>

</div>

</div>

</div>"""




\# ──────────────────────────────────────────────

\#  CSS

\# ──────────────────────────────────────────────


CSS = """

:root{

--bg:#03040a;--s1:#080d18;--s2:#0c1422;

--border:#162030;--border2:#1e3048;

--a1:#00e5ff;--a2:#ff3d6b;--a3:#39ff84;--a4:#ffcc00;--a5:#bf5af2;

--txt:#dde8f5;--muted:#4a6a8a;--muted2:#2a4a6a;

}

\*{margin:0;padding:0;box-sizing:border-box}

html{scroll-behavior:smooth}

body{background:var(--bg);color:var(--txt);font-family:'Space Mono',monospace;font-size:13px;line-height:1.7;overflow-x:hidden;}

body::after{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,0,0,0.07) 2px,rgba(0,0,0,0.07) 4px);pointer-events:none;z-index:9997;}

#cursor{position:fixed;width:12px;height:12px;background:var(--a1);border-radius:50%;pointer-events:none;z-index:99999;transform:translate(-50%,-50%);mix-blend-mode:screen;transition:width .2s,height .2s;}

#cursor-ring{position:fixed;width:36px;height:36px;border:1px solid rgba(0,229,255,.4);border-radius:50%;pointer-events:none;z-index:99998;transform:translate(-50%,-50%);transition:transform .15s ease-out;}

.grid-lines{position:fixed;inset:0;z-index:0;background-image:linear-gradient(rgba(0,229,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(0,229,255,.025) 1px,transparent 1px);background-size:80px 80px;pointer-events:none;animation:gridDrift 20s linear infinite;}

@keyframes gridDrift{from{background-position:0 0}to{background-position:80px 80px}}

#stars{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none}

.star{position:absolute;background:#fff;border-radius:50%;animation:twinkle var(--d,3s) infinite var(--delay,0s)}

@keyframes twinkle{0%,100%{opacity:.1}50%{opacity:.9}}

#sidebar{position:fixed;left:0;top:0;bottom:0;width:220px;background:rgba(3,4,10,.95);border-right:1px solid var(--border);z-index:1000;display:flex;flex-direction:column;padding:32px 0;backdrop-filter:blur(20px);}

.sidebar-logo{padding:0 24px 32px;border-bottom:1px solid var(--border);margin-bottom:16px;}

.logo-text{font-family:'Bebas Neue',sans-serif;font-size:32px;letter-spacing:.1em;color:var(--a1);text-shadow:0 0 30px rgba(0,229,255,.5);display:block;}

.logo-sub{font-size:9px;letter-spacing:.2em;color:var(--muted);text-transform:uppercase;}

.nav-item{display:flex;align-items:center;gap:12px;padding:10px 24px;font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--muted);cursor:pointer;border-left:2px solid transparent;transition:all .2s;text-decoration:none;}

.nav-item:hover{color:var(--txt);background:rgba(0,229,255,.04)}

.nav-item.active{color:var(--a1);border-left-color:var(--a1);background:rgba(0,229,255,.06)}

.nav-dot{width:6px;height:6px;border-radius:50%;background:currentColor;flex-shrink:0}

.nav-section-label{padding:20px 24px 6px;font-size:9px;letter-spacing:.3em;color:var(--muted2);text-transform:uppercase;}

main{margin-left:220px;min-height:100vh}

.wrap{position:relative;z-index:10;max-width:1400px;margin:0 auto;padding:0 48px}

#hero{min-height:100vh;display:flex;align-items:center;padding:80px 48px;position:relative;overflow:hidden;}

.hero-bg-text{position:absolute;font-family:'Bebas Neue',sans-serif;font-size:clamp(120px,18vw,280px);color:rgba(0,229,255,.03);top:50%;left:50%;transform:translate(-50%,-50%);white-space:nowrap;pointer-events:none;animation:bgPulse 6s ease-in-out infinite;}

@keyframes bgPulse{0%,100%{opacity:.5}50%{opacity:1}}

.hero-content{max-width:900px;position:relative;z-index:2}

.hero-badge{display:inline-flex;align-items:center;gap:8px;padding:6px 16px;border:1px solid rgba(0,229,255,.3);font-size:10px;letter-spacing:.2em;color:var(--a1);text-transform:uppercase;margin-bottom:32px;background:rgba(0,229,255,.05);}

.pulse-dot{width:7px;height:7px;border-radius:50%;background:var(--a3);animation:pulse 2s infinite}

@keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(57,255,132,.6)}50%{box-shadow:0 0 0 8px rgba(57,255,132,0)}}

.hero-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(72px,12vw,160px);line-height:.9;letter-spacing:.05em;color:var(--txt);margin-bottom:4px;animation:fadeUp .6s .2s both;}

.hero-title .outline{-webkit-text-stroke:2px var(--a1);color:transparent;text-shadow:0 0 40px rgba(0,229,255,.3);}

.hero-tagline{font-family:'Libre Baskerville',serif;font-style:italic;font-size:22px;color:var(--muted);margin-bottom:48px;animation:fadeUp .6s .3s both;}

.hero-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:var(--border);border:1px solid var(--border);animation:fadeUp .6s .4s both;max-width:700px;}

.stat-box{background:var(--s1);padding:20px 24px;transition:background .2s;}

.stat-box:hover{background:var(--s2)}

.stat-num{font-family:'Bebas Neue',sans-serif;font-size:36px;color:var(--a1);text-shadow:0 0 20px rgba(0,229,255,.4);display:block;line-height:1;}

.stat-lbl{font-size:10px;letter-spacing:.1em;color:var(--muted);text-transform:uppercase;margin-top:4px}

@keyframes fadeUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}

.section{padding:100px 48px;border-top:1px solid var(--border);position:relative}

.section-eyebrow{font-size:10px;letter-spacing:.3em;color:var(--a1);text-transform:uppercase;margin-bottom:16px;display:flex;align-items:center;gap:12px;}

.section-eyebrow::before{content:'';width:40px;height:1px;background:var(--a1)}

.section-title{font-family:'Bebas Neue',sans-serif;font-size:clamp(40px,6vw,80px);line-height:.95;letter-spacing:.03em;color:var(--txt);margin-bottom:12px;}

.section-title .accent{color:var(--a1)}

.section-desc{color:var(--muted);font-size:13px;max-width:600px;margin-bottom:60px;line-height:1.8}

.tables-grid{display:flex;flex-direction:column;gap:2px}

.db-table{background:var(--s1);border:1px solid var(--border);overflow:hidden;transition:border-color .2s;}

.db-table:hover{border-color:var(--border2)}

.db-table-head{display:flex;align-items:center;justify-content:space-between;padding:14px 20px;background:var(--s2);border-bottom:1px solid var(--border);cursor:pointer;user-select:none;}

.db-table-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.1em;color:var(--txt);}

.db-meta{display:flex;align-items:center;gap:12px}

.db-badge{font-size:9px;padding:3px 10px;letter-spacing:.15em;text-transform:uppercase;border-radius:2px;border:1px solid;}

.db-badge.core{color:var(--a1);border-color:rgba(0,229,255,.3);background:rgba(0,229,255,.06)}

.db-badge.biz{color:var(--a5);border-color:rgba(191,90,242,.3);background:rgba(191,90,242,.06)}

.db-badge.legal{color:var(--a2);border-color:rgba(255,61,107,.3);background:rgba(255,61,107,.06)}

.db-badge.life{color:var(--a3);border-color:rgba(57,255,132,.3);background:rgba(57,255,132,.06)}

.db-badge.social{color:var(--a4);border-color:rgba(255,204,0,.3);background:rgba(255,204,0,.06)}

.db-badge.system{color:var(--muted);border-color:var(--border2);background:var(--s2)}

.db-chevron{font-size:11px;color:var(--muted);transition:transform .2s}

.db-table.open .db-chevron{transform:rotate(180deg)}

.db-body{display:none;overflow:auto}

.db-table.open .db-body{display:block}

.db-fields-header{display:grid;grid-template-columns:200px 130px 60px 1fr 80px;gap:12px;padding:8px 20px;background:rgba(0,0,0,.3);font-size:9px;letter-spacing:.15em;color:var(--muted2);text-transform:uppercase;border-bottom:1px solid var(--border);}

.db-row{display:grid;grid-template-columns:200px 130px 60px 1fr 80px;gap:12px;padding:10px 20px;border-bottom:1px solid rgba(22,32,48,.5);align-items:start;transition:background .15s;}

.db-row:last-child{border-bottom:none}

.db-row:hover{background:rgba(0,229,255,.025)}

.f-name{color:var(--a3);font-weight:700;word-break:break-all}

.f-type{color:var(--a5);font-size:11px}

.f-req{font-size:10px;color:var(--a2)}

.f-desc{color:var(--muted);font-size:11px;line-height:1.6}

.f-tag{font-size:9px;padding:2px 7px;border-radius:2px;display:inline-block;white-space:nowrap;}

.f-tag.pk{background:rgba(0,229,255,.15);color:var(--a1)}

.f-tag.fk{background:rgba(191,90,242,.15);color:var(--a5)}

.f-tag.idx{background:rgba(57,255,132,.15);color:var(--a3)}

.f-tag.enc{background:rgba(255,61,107,.15);color:var(--a2)}

.f-tag.auto{background:rgba(255,204,0,.15);color:var(--a4)}

.wf-grid{display:flex;flex-direction:column;gap:32px}

.wf-card{background:var(--s1);border:1px solid var(--border);overflow:hidden;position:relative;}

.wf-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:linear-gradient(to bottom,var(--a1),var(--a5));}

.wf-head{padding:20px 28px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;cursor:pointer;}

.wf-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:.05em;color:var(--txt);display:flex;align-items:center;gap:14px;}

.wf-icon{font-size:20px}

.wf-tags{display:flex;gap:8px;flex-wrap:wrap}

.wf-tag{font-size:9px;padding:3px 10px;letter-spacing:.12em;text-transform:uppercase;border:1px solid;border-radius:2px;}

.tag-critical{color:var(--a2);border-color:rgba(255,61,107,.4);background:rgba(255,61,107,.06)}

.tag-scheduled{color:var(--a4);border-color:rgba(255,204,0,.4);background:rgba(255,204,0,.06)}

.tag-payment{color:var(--a3);border-color:rgba(57,255,132,.4);background:rgba(57,255,132,.06)}

.tag-ui{color:var(--a1);border-color:rgba(0,229,255,.4);background:rgba(0,229,255,.06)}

.tag-pro{color:var(--a5);border-color:rgba(191,90,242,.4);background:rgba(191,90,242,.06)}

.tag-ai{color:var(--a1);border-color:rgba(0,229,255,.4);background:rgba(0,229,255,.1)}

.tag-security{color:var(--a2);border-color:rgba(255,61,107,.4);background:rgba(255,61,107,.06)}

.wf-body{padding:28px;display:none}

.wf-card.open .wf-body{display:block}

.wf-desc{color:var(--muted);font-size:12px;margin-bottom:24px;line-height:1.8;border-left:2px solid var(--border2);padding-left:16px}

.steps-list{display:flex;flex-direction:column;gap:0}

.step{display:flex;gap:20px;position:relative}

.step:not(:last-child)::after{content:'';position:absolute;left:17px;top:40px;bottom:0;width:1px;background:linear-gradient(var(--border2),transparent);}

.step-num{width:34px;height:34px;border-radius:50%;border:1px solid var(--border2);background:var(--s2);display:flex;align-items:center;justify-content:center;font-size:11px;color:var(--a1);flex-shrink:0;margin-top:12px;font-weight:700;}

.step-content{padding:10px 0 28px;flex:1}

.step-name{font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:.05em;color:var(--txt);margin-bottom:6px;}

.step-detail{color:var(--muted);font-size:12px;line-height:1.8;margin-bottom:10px}

.code-label{font-size:9px;letter-spacing:.2em;text-transform:uppercase;color:var(--muted2);margin-bottom:8px;}

.code-block{background:#010204;border:1px solid var(--border2);border-radius:3px;padding:14px 16px;font-size:11px;color:var(--a3);line-height:1.7;white-space:pre;overflow-x:auto;font-family:'Space Mono',monospace;}

.tech-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}

.tech-card{background:var(--s1);border:1px solid var(--border);padding:24px;transition:all .2s;}

.tech-card:hover{border-color:var(--border2);background:var(--s2)}

.tech-logo{font-size:28px;margin-bottom:12px}

.tech-name{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.05em;color:var(--txt);margin-bottom:4px;}

.tech-role{font-size:10px;letter-spacing:.1em;color:var(--a1);text-transform:uppercase;margin-bottom:10px;}

.tech-desc{color:var(--muted);font-size:11px;line-height:1.7;margin-bottom:14px}

.tech-price{font-size:10px;padding:3px 10px;border-radius:2px;background:rgba(57,255,132,.1);color:var(--a3);border:1px solid rgba(57,255,132,.2);display:inline-block;}

.comp-table{width:100%;border-collapse:collapse}

.comp-table th{padding:12px 16px;text-align:left;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted2);background:var(--s2);border-bottom:1px solid var(--border);font-weight:400;}

.comp-table td{padding:12px 16px;border-bottom:1px solid rgba(22,32,48,.5);font-size:12px;vertical-align:middle;}

.comp-table tr:hover td{background:rgba(0,229,255,.02)}

.comp-table .feat{color:var(--txt);font-weight:700;font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:.03em}

.comp-table .highlight-col{background:rgba(0,229,255,.04)!important}

.comp-header-rezzow{color:var(--a1)!important}

.check{color:var(--a3)}.cross{color:var(--a2)}.partial{color:var(--a4)}

.legal-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}

.legal-card{background:var(--s1);border:1px solid var(--border);padding:28px;transition:border-color .2s;}

.legal-card:hover{border-color:var(--border2)}

.legal-icon{font-size:24px;margin-bottom:16px;display:block}

.legal-title{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:.05em;color:var(--txt);margin-bottom:10px;}

.legal-text{color:var(--muted);font-size:12px;line-height:1.8;margin-bottom:16px}

.legal-items{display:flex;flex-direction:column;gap:6px}

.legal-item{font-size:11px;color:var(--muted);padding-left:16px;position:relative;line-height:1.6}

.legal-item::before{content:'→';position:absolute;left:0;color:var(--a1);font-size:10px}

.legal-item.warn::before{content:'⚠';color:var(--a4)}

.legal-item.ok::before{content:'✓';color:var(--a3)}

.pricing-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px;background:var(--border);border:1px solid var(--border);margin-bottom:48px;}

.price-tier{background:var(--s1);padding:40px 28px;position:relative;transition:background .2s;}

.price-tier:hover{background:var(--s2)}

.price-tier.featured{background:linear-gradient(160deg,#080d18,#0a142a);border-top:2px solid var(--a1);}

.featured-badge{position:absolute;top:-1px;left:50%;transform:translateX(-50%);font-size:9px;padding:3px 12px;background:var(--a1);color:var(--bg);letter-spacing:.15em;text-transform:uppercase;font-weight:700;}

.tier-plan{font-size:9px;letter-spacing:.25em;text-transform:uppercase;color:var(--muted);margin-bottom:10px}

.tier-name{font-family:'Bebas Neue',sans-serif;font-size:40px;letter-spacing:.05em;color:var(--txt);margin-bottom:6px;}

.tier-price{font-family:'Libre Baskerville',serif;font-size:48px;color:var(--a1);margin-bottom:8px;line-height:1;}

.tier-price sub{font-size:16px;color:var(--muted);vertical-align:middle}

.tier-desc{font-size:11px;color:var(--muted);margin-bottom:28px;line-height:1.6}

.tier-features{display:flex;flex-direction:column;gap:9px}

.tier-feature{font-size:12px;display:flex;gap:10px;align-items:flex-start;}

.tier-feature .f-check{color:var(--a3);flex-shrink:0;margin-top:1px}

.tier-feature .f-cross{color:var(--muted2);flex-shrink:0;margin-top:1px}

.tier-feature .f-text{color:var(--muted);line-height:1.5}

.tier-feature.active .f-text{color:var(--txt)}

.projection-table{width:100%;border-collapse:collapse;margin-top:32px}

.projection-table th{padding:12px 16px;font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted2);background:var(--s2);border-bottom:1px solid var(--border);font-weight:400;text-align:right;}

.projection-table th:first-child{text-align:left}

.projection-table td{padding:12px 16px;border-bottom:1px solid rgba(22,32,48,.5);font-size:12px;text-align:right;}

.projection-table td:first-child{text-align:left;color:var(--txt);font-weight:700}

.projection-table tr:hover td{background:rgba(0,229,255,.02)}

.num-up{color:var(--a3)}.num-neutral{color:var(--muted)}.num-accent{color:var(--a1);font-weight:700}

.costs-grid{display:grid;grid-template-columns:1fr 1fr;gap:24px}

.cost-phase{background:var(--s1);border:1px solid var(--border);padding:28px}

.cost-phase-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.05em;color:var(--txt);margin-bottom:20px;}

.cost-items{display:flex;flex-direction:column;gap:0}

.cost-item{display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid rgba(22,32,48,.6);font-size:12px;}

.cost-item:last-child{border-bottom:none}

.cost-name{color:var(--muted)}

.cost-val{color:var(--a1);font-weight:700;font-family:'Bebas Neue',sans-serif;font-size:15px;letter-spacing:.05em}

.cost-total{display:flex;justify-content:space-between;padding:14px 0 0;margin-top:8px;border-top:1px solid var(--border2);font-weight:700;}

.cost-total .cost-name{color:var(--txt)}

.cost-total .cost-val{color:var(--a3);font-size:20px}

.seo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}

.seo-card{background:var(--s1);border:1px solid var(--border);padding:28px}

.seo-title{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:.05em;color:var(--txt);margin-bottom:6px;}

.seo-priority{font-size:9px;letter-spacing:.15em;text-transform:uppercase;margin-bottom:14px;display:flex;align-items:center;gap:6px;}

.priority-dot{width:6px;height:6px;border-radius:50%}

.high .priority-dot{background:var(--a2)}.high .seo-priority{color:var(--a2)}

.med .priority-dot{background:var(--a4)}.med .seo-priority{color:var(--a4)}

.low .priority-dot{background:var(--a3)}.low .seo-priority{color:var(--a3)}

.seo-items{display:flex;flex-direction:column;gap:6px}

.seo-item{font-size:11px;color:var(--muted);padding-left:14px;position:relative;line-height:1.6}

.seo-item::before{content:'»';position:absolute;left:0;color:var(--a1)}

.reveal{opacity:0;transform:translateY(40px);transition:opacity .6s,transform .6s}

.reveal.visible{opacity:1;transform:translateY(0)}

footer{margin-left:220px;padding:60px 48px;border-top:1px solid var(--border);text-align:center;position:relative;z-index:10;}

.footer-logo{font-family:'Bebas Neue',sans-serif;font-size:64px;letter-spacing:.1em;color:transparent;-webkit-text-stroke:1px var(--border2);margin-bottom:16px;}

.footer-text{font-size:11px;letter-spacing:.15em;color:var(--muted)}

[data-tooltip]{position:relative;cursor:help}

[data-tooltip]:hover::after{content:attr(data-tooltip);position:absolute;bottom:calc(100% + 8px);left:0;background:var(--s2);border:1px solid var(--border2);padding:6px 12px;font-size:10px;color:var(--txt);white-space:nowrap;z-index:9999;opacity:1;pointer-events:none;letter-spacing:.05em;}

.arch-diagram{position:relative;width:100%;background:var(--s1);border:1px solid var(--border);padding:48px 32px;overflow:hidden;}

.arch-layer{display:flex;gap:16px;justify-content:center;margin-bottom:0;position:relative;flex-wrap:wrap;}

.arch-node{padding:14px 20px;min-width:120px;border:1px solid;border-radius:3px;text-align:center;font-size:11px;font-weight:700;letter-spacing:.05em;position:relative;cursor:pointer;transition:all .2s;background:var(--bg);}

.arch-node:hover{transform:translateY(-3px);box-shadow:0 8px 30px rgba(0,0,0,.4)}

.n-user{color:var(--a1);border-color:rgba(0,229,255,.4);box-shadow:0 0 20px rgba(0,229,255,.1)}

.n-ui{color:var(--a3);border-color:rgba(57,255,132,.4)}

.n-api{color:var(--a4);border-color:rgba(255,204,0,.4)}

.n-db{color:var(--a5);border-color:rgba(191,90,242,.4)}

.n-ext{color:var(--a2);border-color:rgba(255,61,107,.4)}

.arch-label{text-align:center;font-size:10px;letter-spacing:.15em;text-transform:uppercase;color:var(--muted2);margin-bottom:16px;margin-top:4px;}

.arch-connector{display:flex;justify-content:center;align-items:center;height:36px;position:relative;}

.arch-connector::before{content:'';position:absolute;width:1px;height:100%;background:var(--border2);}

.arch-connector::after{content:'▼';color:var(--muted2);font-size:12px;position:relative;z-index:1;background:var(--s1);padding:2px 8px;}

@media(max-width:900px){

#sidebar{display:none}

main,footer{margin-left:0}

.section{padding:60px 24px}

.pricing-grid{grid-template-columns:1fr}

.costs-grid{grid-template-columns:1fr}

#hero{padding:80px 24px}

.hero-stats{grid-template-columns:repeat(2,1fr)}

.db-fields-header,.db-row{grid-template-columns:140px 90px 40px 1fr;font-size:11px}

.db-row>span:last-child{display:none}

}

"""


\# ──────────────────────────────────────────────

\#  JAVASCRIPT

\# ──────────────────────────────────────────────


JS = r"""

// ── Cursor ──────────────────────────────────

const cur = document.getElementById('cursor');

const ring = document.getElementById('cursor-ring');

document.addEventListener('mousemove', e => {

cur.style.left = e.clientX + 'px';

cur.style.top  = e.clientY + 'px';

setTimeout(() => {

ring.style.left = e.clientX + 'px';

ring.style.top  = e.clientY + 'px';

}, 80);

});


// ── Stars ────────────────────────────────────

const starsEl = document.getElementById('stars');

for (let i = 0; i < 120; i++) {

const s = document.createElement('div');

s.className = 'star';

s.style.cssText = `

left:${Math.random()\*100}%;top:${Math.random()\*100}%;

width:${Math.random()\*2+1}px;height:${Math.random()\*2+1}px;

--d:${Math.random()\*4+2}s;--delay:${Math.random()\*4}s`;

starsEl.appendChild(s);

}


// ── Scroll reveal ────────────────────────────

const io = new IntersectionObserver(entries => {

entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });

}, { threshold: 0.1 });

document.querySelectorAll('.reveal').forEach(el => io.observe(el));


// ── Counters ─────────────────────────────────

function animateCounter(el) {

const target = +el.dataset.target;

const dur = 1200;

const step = target / (dur / 16);

let cur = 0;

const t = setInterval(() => {

cur = Math.min(cur + step, target);

el.textContent = Math.round(cur);

if (cur >= target) clearInterval(t);

}, 16);

}

const cio = new IntersectionObserver(entries => {

entries.forEach(e => {

if (e.isIntersecting) { animateCounter(e.target); cio.unobserve(e.target); }

});

}, { threshold: 0.5 });

document.querySelectorAll('.counter').forEach(el => cio.observe(el));


// ── Nav highlight on scroll ──────────────────

const sections = document.querySelectorAll('section[id]');

const sio = new IntersectionObserver(entries => {

entries.forEach(e => {

if (e.isIntersecting) {

document.querySelectorAll('.nav-item').forEach(a => {

1. classList.toggle('active', a.getAttribute('href') === '#' + e.target.id);

});

}

});

}, { rootMargin: '-40% 0px -50% 0px' });

sections.forEach(s => sio.observe(s));


// ── Toggle DB table ──────────────────────────

function toggleTable(id) {

const el = document.getElementById(id);

el.classList.toggle('open');

}


// ── Toggle WF card ───────────────────────────

function toggleWF(id) {

const el = document.getElementById(id);

el.classList.toggle('open');

}

"""


\# ──────────────────────────────────────────────

\#  ARCHITECTURE DIAGRAM (inline)

\# ──────────────────────────────────────────────


ARCH\_HTML = """

<div class="arch-diagram reveal">

<div class="arch-label">— CAPA DE USUARIO —</div>

<div class="arch-layer">

<div class="arch-node n-user" data-tooltip="Web App Bubble">🌐 Web App</div>

<div class="arch-node n-user" data-tooltip="PWA móvil">📱 Mobile PWA</div>

<div class="arch-node n-user" data-tooltip="API pública Enterprise">🔌 API Pública</div>

</div>

<div class="arch-connector"></div>

<div class="arch-label">— CAPA DE PRESENTACIÓN (Bubble Frontend) —</div>

<div class="arch-layer">

<div class="arch-node n-ui" data-tooltip="Mapbox GL JS">🗺️ Mapa</div>

<div class="arch-node n-ui" data-tooltip="Fichas 360°">🃏 Fichas País</div>

<div class="arch-node n-ui" data-tooltip="Chat IA flotante">🤖 AI Chat</div>

<div class="arch-node n-ui" data-tooltip="Marketplace">🤝 Marketplace</div>

<div class="arch-node n-ui" data-tooltip="Job Board">💼 Jobs</div>

</div>

<div class="arch-connector"></div>

<div class="arch-label">— CAPA DE LÓGICA (Bubble Backend Workflows) —</div>

<div class="arch-layer">

<div class="arch-node n-api" data-tooltip="API Connector → OpenAI">🧠 IA Engine</div>

<div class="arch-node n-api" data-tooltip="Stripe + Webhooks">💳 Payments</div>

<div class="arch-node n-api" data-tooltip="Scheduled WF + Apify">🔄 Scraper</div>

<div class="arch-node n-api" data-tooltip="SendGrid + OneSignal">📬 Notif.</div>

<div class="arch-node n-api" data-tooltip="PDFMonkey + Calendly">📄 Docs</div>

</div>

<div class="arch-connector"></div>

<div class="arch-label">— CAPA DE DATOS (Bubble DB + Externos) —</div>

<div class="arch-layer">

<div class="arch-node n-db" data-tooltip="Base de datos Bubble">🗄️ Bubble DB</div>

<div class="arch-node n-db" data-tooltip="Filestack para uploads">📁 File Storage</div>

<div class="arch-node n-db" data-tooltip="Caché respuestas IA">⚡ AI Cache</div>

</div>

<div class="arch-connector"></div>

<div class="arch-label">— SERVICIOS EXTERNOS —</div>

<div class="arch-layer">

<div class="arch-node n-ext">OpenAI</div>

<div class="arch-node n-ext">Apify</div>

<div class="arch-node n-ext">Stripe</div>

<div class="arch-node n-ext">Numbeo</div>

<div class="arch-node n-ext">Mapbox</div>

<div class="arch-node n-ext">PDFMonkey</div>

<div class="arch-node n-ext">SendGrid</div>

<div class="arch-node n-ext">OneSignal</div>

<div class="arch-node n-ext">Perplexity</div>

<div class="arch-node n-ext">Calendly</div>

</div>

</div>

"""


\# ──────────────────────────────────────────────

\#  SIDEBAR NAV

\# ──────────────────────────────────────────────


SIDEBAR = """

<nav id="sidebar">

<div class="sidebar-logo">

<span class="logo-text">REZZOW</span>

<span class="logo-sub">Architecture v2.0 — Bubble.io</span>

</div>

<div class="nav-section-label">Fundamentos</div>

<a class="nav-item active" href="#hero"><span class="nav-dot"></span>Overview</a>

<a class="nav-item" href="#architecture"><span class="nav-dot"></span>Arquitectura</a>

<a class="nav-item" href="#competitors"><span class="nav-dot"></span>Competidores</a>

<div class="nav-section-label">Técnico</div>

<a class="nav-item" href="#database"><span class="nav-dot"></span>Base de Datos</a>

<a class="nav-item" href="#workflows"><span class="nav-dot"></span>Workflows</a>

<a class="nav-item" href="#stack"><span class="nav-dot"></span>Stack Técnico</a>

<div class="nav-section-label">Negocio</div>

<a class="nav-item" href="#legal"><span class="nav-dot"></span>Legal &amp; RGPD</a>

<a class="nav-item" href="#revenue"><span class="nav-dot"></span>Modelo Negocio</a>

<a class="nav-item" href="#costs"><span class="nav-dot"></span>Costes</a>

<a class="nav-item" href="#seo"><span class="nav-dot"></span>SEO &amp; Adquisición</a>

</nav>

"""


\# ──────────────────────────────────────────────

\#  ASSEMBLE

\# ──────────────────────────────────────────────


def build\_html() -> str:

tables\_html    = render\_tables()

workflows\_html = render\_workflows()

tech\_html      = render\_tech()

comp\_html      = render\_competitors()

legal\_html     = render\_legal()

pricing\_html   = render\_pricing()

proj\_html      = render\_projections()

seo\_html       = render\_seo()

costs\_html     = render\_costs()


return f"""<!DOCTYPE html>

<html lang="es">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>REZZOW — Arquitectura de Producto v2.0</title>

<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Mono:wght@400;700&family=Libre+Baskerville:ital,wght@0,400;1,400&display=swap" rel="stylesheet">

<style>{CSS}</style>

</head>

<body>

<div id="cursor"></div>

<div id="cursor-ring"></div>

<div id="stars"></div>

<div class="grid-lines"></div>


{SIDEBAR}


<main>


<!-- ═══ HERO ═══ -->

<section id="hero">

<div class="hero-bg-text">REZZOW</div>

<div class="hero-content">

<div class="hero-badge"><span class="pulse-dot"></span>Documento de Arquitectura — Bubble.io — v2.0</div>

<h1 class="hero-title">REZ<span class="outline">ZOW</span></h1>

<p class="hero-tagline">Movilidad Global · Negocios Internacionales · Soft Landing</p>

<div class="hero-stats">

<div class="stat-box"><span class="stat-num counter" data-target="195">0</span><div class="stat-lbl">Países cubiertos</div></div>

<div class="stat-box"><span class="stat-num counter" data-target="13">0</span><div class="stat-lbl">Tablas en DB</div></div>

<div class="stat-box"><span class="stat-num counter" data-target="8">0</span><div class="stat-lbl">Workflows</div></div>

<div class="stat-box"><span class="stat-num counter" data-target="16">0</span><div class="stat-lbl">Herramientas</div></div>

</div>

</div>

</section>


<!-- ═══ ARCHITECTURE ═══ -->

<section id="architecture" class="section">

<div class="wrap">

<div class="section-eyebrow">Visión General</div>

<h2 class="section-title">ARQUITECTURA<br><span class="accent">DEL SISTEMA</span></h2>

<p class="section-desc">Diagrama de flujo de datos completo. Bubble.io actúa como orquestador central entre la UI, los Backend Workflows y los servicios externos.</p>

{ARCH\_HTML}

</div>

</section>


<!-- ═══ COMPETITORS ═══ -->

<section id="competitors" class="section">

<div class="wrap">

<div class="section-eyebrow">Análisis de Mercado</div>

<h2 class="section-title">COMPARATIVA<br><span class="accent">COMPETIDORES</span></h2>

<p class="section-desc">Ningún competidor cubre simultáneamente los cuatro vectores: negocios B2B, legal/burocrático, vida/relocation y capital social.</p>

<div style="overflow-x:auto" class="reveal">

{comp\_html}

</div>

</div>

</section>


<!-- ═══ DATABASE ═══ -->

<section id="database" class="section">

<div class="wrap">

<div class="section-eyebrow">Capa de Datos</div>

<h2 class="section-title">BASE DE<br><span class="accent">DATOS</span></h2>

<p class="section-desc">13 tablas organizadas en 5 capas lógicas. Haz clic en cada tabla para expandir sus campos. Tipos de datos según nomenclatura de Bubble.io.</p>

{tables\_html}

</div>

</section>


<!-- ═══ WORKFLOWS ═══ -->

<section id="workflows" class="section">

<div class="wrap">

<div class="section-eyebrow">Lógica de Negocio</div>

<h2 class="section-title">WORKFLOWS<br><span class="accent">CRÍTICOS</span></h2>

<p class="section-desc">8 workflows detallados con lógica paso a paso y código de configuración. Los más complejos incluyen integración IA con datos en vivo.</p>

{workflows\_html}

</div>

</section>


<!-- ═══ STACK ═══ -->

<section id="stack" class="section">

<div class="wrap">

<div class="section-eyebrow">Infraestructura</div>

<h2 class="section-title">STACK<br><span class="accent">TÉCNICO</span></h2>

<p class="section-desc">16 herramientas seleccionadas para máxima velocidad de desarrollo, coste controlado y escalabilidad. Todas compatibles con Bubble.io.</p>

{tech\_html}

</div>

</section>


<!-- ═══ LEGAL ═══ -->

<section id="legal" class="section">

<div class="wrap">

<div class="section-eyebrow">Compliance</div>

<h2 class="section-title">LEGAL &amp;<br><span class="accent">PRIVACIDAD</span></h2>

<p class="section-desc">Arquitectura de privacidad completa para operar en UE (RGPD), EEUU (CCPA) y Latam (LGPD). Privacy by design, no como afterthought.</p>

{legal\_html}

</div>

</section>


<!-- ═══ REVENUE ═══ -->

<section id="revenue" class="section">

<div class="wrap">

<div class="section-eyebrow">Business Model</div>

<h2 class="section-title">MODELO DE<br><span class="accent">NEGOCIO</span></h2>

<p class="section-desc">Freemium + SaaS con múltiples streams de ingresos. Proyecciones financieras a 36 meses basadas en benchmarks del sector.</p>

{pricing\_html}

<div class="section-eyebrow" style="margin-top:60px;margin-bottom:16px">Proyecciones Financieras</div>

<div style="color:var(--muted);font-size:12px;margin-bottom:8px">Conversión free→pro: 5% · Churn mensual: 5% · CAC estimado: €12 (SEO-first) · LTV Pro: €87</div>

<div style="overflow-x:auto">

{proj\_html}

</div>

<div style="margin-top:24px;padding:16px 20px;background:rgba(0,229,255,.04);border:1px solid rgba(0,229,255,.2);font-size:12px;color:var(--muted)">

<span style="color:var(--a1);font-weight:700">⚡ Hitos: </span>

Mes 6 = Ramen profitable · Mes 12 = Seed round-ready (€250k ARR) · Mes 24 = Serie A territory · Mes 36 = €2.6M ARR proyectado

</div>

</div>

</section>


<!-- ═══ COSTS ═══ -->

<section id="costs" class="section">

<div class="wrap">

<div class="section-eyebrow">Inversión Inicial</div>

<h2 class="section-title">ESTIMACIÓN<br><span class="accent">DE COSTES</span></h2>

<p class="section-desc">Desglose completo de costes de desarrollo (one-time) y operación mensual (recurring). Basado en solo-founder + freelancers puntuales.</p>

{costs\_html}

</div>

</section>


<!-- ═══ SEO ═══ -->

<section id="seo" class="section">

<div class="wrap">

<div class="section-eyebrow">Crecimiento Orgánico</div>

<h2 class="section-title">SEO &amp;<br><span class="accent">ADQUISICIÓN</span></h2>

<p class="section-desc">Estrategia SEO-first para minimizar CAC. 195 países × múltiples tipos de visa × 3 idiomas = miles de páginas indexables con intención de búsqueda alta.</p>

{seo\_html}

</div>

</section>


</main>


<footer>

<div class="footer-logo">REZZOW</div>

<div class="footer-text">

Documento de Arquitectura v2.0 — Bubble.io — Generado con Python<br>

<span style="color:var(--muted2);font-size:10px">Confidencial · Para uso interno del equipo fundador</span>

</div>

</footer>


<script>{JS}</script>

</body>

</html>"""




\# ──────────────────────────────────────────────

\#  MAIN

\# ──────────────────────────────────────────────


if \_\_name\_\_ == "\_\_main\_\_":

html = build\_html()

output\_file = "index.html"

with open(output\_file, "w", encoding="utf-8") as f:

f.write(html)

size\_kb = len(html.encode()) / 1024

print(f"✅  {output\_file} generado correctamente")

print(f"📦  Tamaño: {size\_kb:.1f} KB")

print(f"📄  Líneas de HTML: {html.count(chr(10)):,}")

print()

print("── Para GitHub Pages ──────────────────────────")

print("1. git init")

print("2. git add index.html")

print('3. git commit -m "REZZOW architecture v2.0"')

print("4. git remote add origin https://github.com/TU\_USUARIO/rezzow-architecture.git")

print("5. git push -u origin main")

print("6. GitHub > Settings > Pages > Source: main / root")

print("   → Tu doc en:  https://TU\_USUARIO.github.io/rezzow-architecture/")
